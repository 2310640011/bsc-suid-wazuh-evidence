BA Linux Hardening - Evidence Package
Host: wazuh
Role: Wazuh Manager

01_original_detection
Urspruengliche Manager-Beweise fuer Detection Engineering.
Enthaelt insbesondere Alerts der Regeln 100202 und 100203 sowie den damaligen Regelstand.

02_sca
Wazuh-SCA-Nachweise fuer den verwundbaren und den gehaerteten Zustand.

03_d1_retest
Dokumentierter D1-Retest auf Manager-Seite mit Regelstaenden, Syntaxpruefung, Alert-Zaehlern und Alert 100202.

04_recheck
Manager-Recheck vom 04.08.2026 mit Alerts 100202 und 100203.

05_current_config
Aktueller Regelstand und dokumentierter Zustand des Wazuh-Managers.

06_active_response
Aktueller Active-Response-Konfigurationsausschnitt und zugehoeriger Alert der Regel 100202.

99_inventory
Inventar des finalen Manager-Beweispakets.

SHA256SUMS_ALL.txt
SHA-256-Pruefsummen aller Dateien des finalen Beweispakets.
