BA Linux Hardening - Evidence Package
Host: noharded

01_original_tests_20260707
Fruehe Testserie mit urspruenglichen Test-, H3- und FINAL-Archiven sowie SHA-256-Nachweisen.

02_d1_retest_20260716
Dokumentierter D1-Retest zur SUID-Rechteausweitung.
Enthaelt Positivtest, Negativkontrollen, auditd-Rohdaten,
interpretierte Auditdaten, Zustandspruefungen und SHA-256-Nachweise.

03_recheck_20260804
Spaeterer Hardening-Retest und finaler Hardening-Recheck.

04_active_response_20260814
Nachweis des Active-Response-Hardening-Tests inklusive SHA-256-Pruefsumme.

99_inventory
Inventar der urspruenglich auf /root vorhandenen Beweisdateien
sowie Inhaltsuebersicht der vorhandenen tar.gz-Archive.

SHA256SUMS_ALL.txt
SHA-256-Pruefsummen der Dateien im finalen Beweisverzeichnis.
